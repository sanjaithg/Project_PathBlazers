
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Image
import cv2
import numpy as np
from cv_bridge import CvBridge

class BallFollower(Node):

    def __init__(self):
        super().__init__('ball_follower')
        self.subscription = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.listener_callback,
            10)
        self.publisher_ = self.create_publisher(Twist, '/my_robot/cmd_vel', 10)
        self.bridge = CvBridge()
        
        # Proportional control parameters
        self.kp_angular = 0.1
        self.kp_linear = 0.1

        self.desired_distance = 1.0  # Desired distance to maintain from the ball in units

    def radius_to_distance(self, radius):
        # Given data points
        d = 0.0011*(radius**2) - 0.1173*radius + 3.885
        return d
    def listener_callback(self, msg):
        try:
            # Convert ROS Image message to OpenCV image
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
            hsv_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2HSV)
            lower_bound = (0, 100, 100)
            upper_bound = (10, 255, 255)
            
            # Create a binary mask where the color range is within the bounds
            mask = cv2.inRange(hsv_image, lower_bound, upper_bound)
            
            blur = cv2.GaussianBlur(mask, (1, 1), 0)
            _, x1 = cv2.threshold(blur, 130, 220, cv2.THRESH_BINARY)
            circles = cv2.HoughCircles(x1, cv2.HOUGH_GRADIENT, 1, 25, param1=8, param2=15, minRadius=6, maxRadius=100)
            twist = Twist()

            if circles is not None:
                circles = np.uint16(np.around(circles))
                for i in circles[0, :]:
                    center = (i[0], i[1])
                    radius = i[2]
                    
                    # Circle center and outline
                    cv2.circle(cv_image, center, 1, (0, 100, 100), 5)
                    cv2.circle(cv_image, center, radius, (255, 0, 0), 2)
                    cv2.putText(cv_image, ( '(' + str(i[0]) + ',' + str(i[1]) + ')' +', r:' + str(i[2])), (i[0] - 25, i[1] - 25), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

                    # Calculate the error between the ball's center and the image center
                    image_center_x = cv_image.shape[1] / 2
                    error_x = center[0] - image_center_x
                    
                    # Proportional control for angular velocity
                    angular_z = - self.kp_angular * error_x
                    twist.angular.z = angular_z
                    
                    # Calculate the current distance based on the radius
                    current_distance = self.radius_to_distance(radius)
                    error_distance =  current_distance - self.desired_distance
                    
                    # Proportional control for linear velocity
                    linear_x = self.kp_linear * error_distance
                    twist.linear.x = linear_x

            # Publish the twist message to control the robot
            self.publisher_.publish(twist)

            # Use the mask to extract the color from the original image
            result_image = cv_image.copy()
            result_image[mask == 0] = 0
            
            # Display the original image and the result image using OpenCV
            cv2.imshow("Original Image", cv_image)
            cv2.imshow("Filtered Image", result_image)
            cv2.imshow("Thresh Image", x1)

            cv2.waitKey(1)
        
        except Exception as e:
            self.get_logger().error(f"Error converting image: {e}")


def main(args=None):
    rclpy.init(args=args)
    node = BallFollower()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
