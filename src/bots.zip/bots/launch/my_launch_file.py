import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, TextSubstitution

def generate_launch_description():
    # Declare the world argument with an absolute path default
    world_default = '/home/hillman/ROS2_NEW/pathblazers/src/bots/world/world.sdf'
    world_arg = DeclareLaunchArgument(
        'world', default_value=world_default,
        description='Absolute path to the Gazebo world file to load'
    )

    pkg_ros_gz_sim = '/opt/ros/jazzy/share/ros_gz_sim'  # Usually fixed path for ROS 2 Jazzy

    gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_ros_gz_sim, 'launch', 'gz_sim.launch.py')
        ),
        launch_arguments={
            'gz_args': [LaunchConfiguration('world'), TextSubstitution(text=' -r -v -v1')],
            'on_exit_shutdown': 'true'
        }.items()
    )

    ld = LaunchDescription()
    ld.add_action(world_arg)
    ld.add_action(gazebo_launch)
    return ld
